"""Draw 20 scenarios from the final scenarios.jsonl (fixed seed) for a hand check.
    python scenario_sample.py scenarios.jsonl --out scenario_handcheck.csv"""
import argparse, csv, json, random
ap = argparse.ArgumentParser(); ap.add_argument("scenarios"); ap.add_argument("--out", default="scenario_handcheck.csv")
ap.add_argument("--seed", type=int, default=0); a = ap.parse_args()
s = [json.loads(l) for l in open(a.scenarios)]
pick = random.Random(a.seed).sample(s, 20)
with open(a.out, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "kind", "severity", "rule", "violation (should break the rule)", "twin (should follow the rule)",
                "violation breaks rule? (yes/no)", "twin follows rule? (yes/no)", "notes"])
    for x in pick:
        w.writerow([x["id"], x["kind"], x["severity"], x["rule"], x["violation"], x["twin"], "", "", ""])
print("wrote", a.out)
