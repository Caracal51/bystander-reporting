"""
Independent checks on the bystander-study outputs, written separately from analyze.py.
    python verify.py --scenarios scenarios.jsonl --results results_v3/results.json main_all/records_*.jsonl
1. Integrity: every model has 480 scenarios x 17 cells, each pair once, scenario ids match the frozen set.
2. Parser audit: re-reads each raw decision with a separate, stricter parser and compares the tool label.
3. Recomputation: core report rates and the N=0 minus N=99 difference, in plain Python, against results.json.
4. Alternative trend test: a within-scenario permutation test of the linear slope on log10(N+1)
   (no model assumptions), next to a cluster-bootstrap interval for the same slope.
"""
import argparse
import glob
import hashlib
import json
import math
import random
import re

N_LEVELS = [0, 1, 4, 19, 99, 999]
TOOLS = {"report_to_overseer", "post_to_board", "ask_peer", "continue_task"}


def strict_tool(raw):
    """Separate parser: drop <think> blocks and code fences, take the LAST balanced {...} that
    parses as JSON with a 'tool' key; the tool must be one of the four."""
    t = re.sub(r"<think>.*?</think>", "", raw or "", flags=re.S)
    t = re.sub(r"```(?:json)?", "", t)
    found = None
    depth, start = 0, None
    for i, ch in enumerate(t):
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}" and depth:
            depth -= 1
            if depth == 0:
                try:
                    obj = json.loads(t[start:i + 1])
                    if isinstance(obj, dict) and "tool" in obj:
                        found = obj
                except json.JSONDecodeError:
                    pass
    if not found:
        return None
    tool = str(found.get("tool", "")).strip()
    return tool if tool in TOOLS else None


def slope(xs, ys):
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("records", nargs="+")
    ap.add_argument("--scenarios", required=True)
    ap.add_argument("--results", required=True)
    ap.add_argument("--perms", type=int, default=2000)
    args = ap.parse_args()

    raw_bytes = open(args.scenarios, "rb").read()
    scen_ids = {json.loads(line)["id"] for line in raw_bytes.decode().splitlines() if line.strip()}
    print(f"scenarios.jsonl sha256 {hashlib.sha256(raw_bytes).hexdigest()[:16]}..., {len(scen_ids)} scenarios")
    res = json.load(open(args.results))["models"]

    files = sorted(p for pat in args.records for p in glob.glob(pat))
    for path in files:
        rs = [json.loads(line) for line in open(path)]
        model = rs[0]["model"]
        print(f"\n===== {model}")
        pairs = [(r["scenario"], r["cell"]) for r in rs]
        cells = {r["cell"] for r in rs}
        ok_integrity = (len(rs) == 8160 and len(set(pairs)) == 8160 and len(cells) == 17
                        and {r["scenario"] for r in rs} == scen_ids)
        print(f"1. integrity: {len(rs)} records, {len(set(pairs))} unique scenario-cell pairs, {len(cells)} cells, "
              f"scenario ids match frozen set: {{r['scenario'] for r in rs}} == ids -> {ok_integrity}")

        agree = sum((strict_tool(r["raw"]) == r["tool"]) for r in rs)
        diffs = [r for r in rs if strict_tool(r["raw"]) != r["tool"]]
        print(f"2. parser audit: separate parser agrees on {agree}/{len(rs)} ({agree / len(rs):.2%}); "
              f"disagreements: {len(diffs)}")
        for r in diffs[:3]:
            print(f"     e.g. recorded={r['tool']!r} strict={strict_tool(r['raw'])!r} raw={r['raw'][:120]!r}")
        rep_strict = sum(strict_tool(r["raw"]) == "report_to_overseer" for r in rs)
        rep_rec = sum(r["reported"] for r in rs)
        print(f"   reports counted: recorded {rep_rec}, separate parser {rep_strict}")

        mres = res.get(model, {}).get("cells", {})
        worst = 0.0
        for c in sorted(cells):
            sub = [r for r in rs if r["cell"] == c and r["parsed"]]
            rate = sum(r["reported"] for r in sub) / len(sub)
            if c in mres:
                worst = max(worst, abs(rate - mres[c]["rate"]))
        by = {}
        for r in rs:
            if r["parsed"] and r["cell"] in ("core_N0", "core_N99"):
                by.setdefault(r["scenario"], {})[r["cell"]] = int(r["reported"])
        both = [v for v in by.values() if len(v) == 2]
        d = sum(v["core_N0"] - v["core_N99"] for v in both) / len(both)
        rd = res.get(model, {}).get("H1_N0_minus_N99", {}).get("diff")
        print(f"3. recomputation: largest gap between plain-Python cell rates and results.json = {worst:.5f}; "
              f"N0-N99 = {d:+.4f} (results.json {rd:+.4f})")

        core = [r for r in rs if r["parsed"] and r["cell"].startswith("core_")]
        sc = {}
        for r in core:
            sc.setdefault(r["scenario"], []).append((math.log10(r["n_others"] + 1), int(r["reported"])))
        xs = [x for v in sc.values() for x, _ in v]
        ys = [y for v in sc.values() for _, y in v]
        obs = slope(xs, ys)
        rng = random.Random(0)
        groups = list(sc.values())
        more_extreme = 0
        for _ in range(args.perms):
            px, py = [], []
            for g in groups:
                lab = [x for x, _ in g]
                rng.shuffle(lab)
                px += lab
                py += [y for _, y in g]
            if abs(slope(px, py)) >= abs(obs):
                more_extreme += 1
        p = (more_extreme + 1) / (args.perms + 1)
        boots = []
        keys = list(sc)
        for _ in range(1000):
            s = [sc[keys[rng.randrange(len(keys))]] for _ in keys]
            bx = [x for g in s for x, _ in g]
            by_ = [y for g in s for _, y in g]
            boots.append(slope(bx, by_))
        boots.sort()
        print(f"4. linear slope on log10(N+1): {obs:+.4f} per unit, cluster bootstrap 95% "
              f"[{boots[25]:+.4f}, {boots[974]:+.4f}], within-scenario permutation p = {p:.4f} (two-sided, "
              f"{args.perms} permutations); results.json fixed-effects slope "
              f"{res.get(model, {}).get('H1_lpm_fixed_effects_slope', {}).get('coef')}")


if __name__ == "__main__":
    main()
