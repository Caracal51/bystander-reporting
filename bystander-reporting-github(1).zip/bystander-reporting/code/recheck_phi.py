"""
Re-ask the manipulation-check question for a finished main run, with a longer
answer limit. The decisions are NOT re-generated: each original conversation is
rebuilt exactly (same scenario, same cell, same prompt, the model's own recorded
decision), the same check question is appended, and only the answer is new.

Why: in the first run the check answer was capped at 12 tokens. Phi-4-mini
answers in its tool-call JSON format, so most answers were cut off before any
number. This is a measurement repair, reported as a deviation.

Decision rule, fixed before re-asking: Phi counts as a second model that
registered the number of witnesses if its check accuracy is at least 50% at
N = 99 (core_N99), the pilot's warning threshold.

    python recheck_phi.py --records main_out/records_microsoft_Phi_4_mini_instruct.jsonl \
        --scenarios scenarios.jsonl --model microsoft/Phi-4-mini-instruct --tp 2
Offline test: add --dry-run.
"""

import argparse
import collections
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pilot_bystander import CHECK_QUESTION, check_target, make_backend  # noqa: E402
from run_main import build_messages, make_cells  # noqa: E402

FENCE_RE = re.compile(r"```(?:json)?", re.I)
# A standalone whole number: not part of a name (agent-K7), a time ([14:02]), a path or a decimal.
NUM_RE = re.compile(r"(?<![\w\-:./\[])(\d{1,3}(?:,\d{3})+|\d+)(?![\w:\]/]|\.\d)")


def extract_count(text):
    """The number the model gives as its answer. Order: a bare number; inside a JSON
    answer, numbers in args values, then in the reason; otherwise the first standalone
    number in the text."""
    if not text:
        return None
    t = FENCE_RE.sub("", text).strip()
    if re.fullmatch(r"\d[\d,]*", t):
        return int(t.replace(",", ""))
    m = re.search(r"\{.*\}", t, re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            args = obj.get("args") if isinstance(obj, dict) else None
            parts = []
            if isinstance(args, dict):
                parts += [str(v) for v in args.values()]
            if isinstance(obj, dict):
                parts.append(str(obj.get("reason", "")))
            for p in parts:
                n = NUM_RE.search(p)
                if n:
                    return int(n.group(1).replace(",", ""))
        except json.JSONDecodeError:
            pass
    n = NUM_RE.search(t)
    return int(n.group(1).replace(",", "")) if n else None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--records", required=True)
    ap.add_argument("--scenarios", required=True)
    ap.add_argument("--model", default="microsoft/Phi-4-mini-instruct")
    ap.add_argument("--tp", type=int, default=2)
    ap.add_argument("--max-model-len", type=int, default=4096)
    ap.add_argument("--gpu-mem", type=float, default=0.90)
    ap.add_argument("--merge-system", action="store_true")
    ap.add_argument("--backend", default="vllm")
    ap.add_argument("--concurrency", type=int, default=16)
    ap.add_argument("--provider", default=None)
    ap.add_argument("--max-tokens", type=int, default=120)
    ap.add_argument("--chunk", type=int, default=800)
    ap.add_argument("--out", default="main_out_recheck")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    scen = {}
    with open(args.scenarios) as f:
        for line in f:
            s = json.loads(line)
            scen[s["id"]] = s
    cells = {c["name"]: c for c in make_cells()}
    recs = [json.loads(line) for line in open(args.records)]
    salience = any(r.get("salience") for r in recs)
    print(f"{len(recs)} records, {len(scen)} scenarios, salience={salience}")

    convs = []
    for r in recs:
        msgs = build_messages(scen[r["scenario"]], cells[r["cell"]], salience)
        convs.append(msgs + [{"role": "assistant", "content": r["raw"]},
                             {"role": "user", "content": CHECK_QUESTION}])

    backend = make_backend(args)
    answers = []
    for start in range(0, len(convs), args.chunk):
        batch = convs[start:start + args.chunk]
        texts, _ = backend.generate(batch, n=1, temperature=0.0, max_tokens=args.max_tokens,
                                    seeds=[7 + start + i for i in range(len(batch))])
        answers += [t[0] for t in texts]
        print(f"  {len(answers)}/{len(convs)} re-asked")

    os.makedirs(args.out, exist_ok=True)
    out_path = os.path.join(args.out, os.path.basename(args.records))
    acc = collections.defaultdict(lambda: [0, 0])
    with open(out_path, "w") as f:
        for r, a in zip(recs, answers):
            r["check_raw_v1"], r["check_answer_v1"], r["check_correct_v1"] = (
                r["check_raw"], r["check_answer"], r["check_correct"])
            r["check_raw"] = a
            r["check_answer"] = extract_count(a)
            r["check_correct"] = r["check_answer"] == check_target(r["n_others"])
            r["check_max_tokens"] = args.max_tokens
            acc[r["cell"]][0] += int(r["check_correct"])
            acc[r["cell"]][1] += 1
            f.write(json.dumps(r) + "\n")
    print(f"Written {out_path}")
    print("\nCheck accuracy after re-asking (correct = number of others + 1):")
    for cell in sorted(acc, key=lambda c: (c.split("_")[0], int(c.split("N")[-1]))):
        k, n = acc[cell]
        print(f"  {cell:16s} {k / n:.1%}  ({k}/{n})")
    k, n = acc["core_N99"]
    verdict = "MEETS" if n and k / n >= 0.5 else "DOES NOT MEET"
    print(f"\nRule (fixed before re-asking): core_N99 accuracy >= 50% -> {k / max(n, 1):.1%}: {verdict} the rule.")
    for cell in ("core_N0", "core_N99", "core_N999"):
        sub = [a for r, a in zip(recs, answers) if r["cell"] == cell]
        print(f"\n--- {cell}: most common raw answers")
        for a, c in collections.Counter(x.strip()[:90] for x in sub).most_common(4):
            print(f"  {c} {a!r}")


if __name__ == "__main__":
    main()
