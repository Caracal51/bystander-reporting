"""
Paper trail: recompute every result number printed in the submission from the raw files,
and compare it with what the paper says. Prints one line per check and writes a CSV.

    python paper_trail.py \
        --scenarios scenarios.jsonl --results results_v3/results.json \
        --qwen main_out/records_Qwen_Qwen3_8B.jsonl \
        --phi main_out_recheck/records_microsoft_Phi_4_mini_instruct.jsonl \
        --yi main_out_new/records_01_ai_Yi_1_5_9B_Chat.jsonl \
        --falcon main_out_new/records_tiiuae_Falcon3_7B_Instruct.jsonl \
        --live-summary live_out/live_summary.json \
        --live-records live_out/live_records_Qwen_Qwen3_8B.jsonl \
        --out trail_check.csv

Needs exploratory.py next to it (for the paired bootstrap, same seed as the paper).
"""
import argparse
import collections
import contextlib
import csv
import hashlib
import io
import json
import os
import re
import sys
from decimal import Decimal, ROUND_HALF_UP

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exploratory as ex  # noqa: E402

ap = argparse.ArgumentParser()
for a in ["scenarios", "results", "qwen", "phi", "yi", "falcon", "live-summary", "live-records"]:
    ap.add_argument("--" + a, required=True)
ap.add_argument("--out", default="trail_check.csv")
args = ap.parse_args()

R = json.load(open(args.results))["models"]
KEY = {"Qwen": "Qwen/Qwen3-8B", "Phi": "microsoft/Phi-4-mini-instruct",
       "Yi": "01-ai/Yi-1.5-9B-Chat", "Falcon": "tiiuae/Falcon3-7B-Instruct"}
PATH = {"Qwen": args.qwen, "Phi": args.phi, "Yi": args.yi, "Falcon": args.falcon}
REC = {m: [json.loads(l) for l in open(p)] for m, p in PATH.items()}
NS = [0, 1, 4, 19, 99, 999]
rows = []


def q(v, dp=1, scale=1, sign=False):
    d = (Decimal(str(v).lstrip("+")) * scale).quantize(Decimal(1).scaleb(-dp), rounding=ROUND_HALF_UP)
    s = str(d)
    if sign and d >= 0:
        s = "+" + s
    return s.replace("-", "−")


def pct(v, dp=0):
    return q(v, dp, 100) + "%"


def rng(vals, dp=0):
    lo, hi = min(vals), max(vals)
    return f"{q(lo, dp, 100)}–{q(hi, dp, 100)}%"


def iv(d, dp=1, scale=100):
    return f"{q(d['diff'], dp, scale, True)} [{q(d['ci95'][0], dp, scale, True)}, {q(d['ci95'][1], dp, scale, True)}]"


def coef(d, dp=3):
    return f"{q(d['coef'], dp, 1, True)} [{q(d['ci95'][0], dp, 1, True)}, {q(d['ci95'][1], dp, 1, True)}]"


def check(cid, where, paper, got, source):
    ok = paper.replace(" ", "") == got.replace(" ", "")
    rows.append([cid, where, paper, got, "MATCH" if ok else "MISMATCH", source])


RJ = "results_v3/results.json"

# ---------- scenarios and records ----------
scen = [json.loads(l) for l in open(args.scenarios)]
check("S1", "Methods: Scenarios", "480", str(len(scen)), "scenarios.jsonl: line count")
kinds = collections.Counter(s["kind"] for s in scen)
check("S2", "Methods: Scenarios", "120 per kind", f"{min(kinds.values())}–{max(kinds.values())} per kind"
      if min(kinds.values()) != max(kinds.values()) else f"{min(kinds.values())} per kind",
      "scenarios.jsonl: count of 'kind'")
check("S3", "Code and Data", "2e383863f780eccb",
      hashlib.sha256(open(args.scenarios, "rb").read()).hexdigest()[:16], "scenarios.jsonl: SHA-256")
check("S4", "Methods: Scenarios (one per rule)", "480 distinct rules", f"{len({s['rule'] for s in scen})} distinct rules",
      "scenarios.jsonl: distinct 'rule'")
for m in KEY:
    cells = {r["cell"] for r in REC[m]}
    check(f"S5-{m}", "Methods: Conditions", "17 cells, 8,160 decisions",
          f"{len(cells)} cells, {len(REC[m]):,} decisions", f"records ({m}): cells and lines")
for m, paper in [("Qwen", "3"), ("Phi", "117"), ("Yi", "108"), ("Falcon", "216")]:
    n = sum(not r["parsed"] for r in REC[m])
    check(f"S6-{m}", "Appendix B item 1 (unparsed)", paper, str(n), f"records ({m}): parsed == false")
check("S7", "Methods: Outcome (unparsed %)", "0.04% for Qwen",
      f"{q(sum(not r['parsed'] for r in REC['Qwen']) / len(REC['Qwen']), 2, 100)}% for Qwen", "records (Qwen)")
others = [sum(not r["parsed"] for r in REC[m]) / len(REC[m]) for m in ["Phi", "Yi", "Falcon"]]
check("S8", "Methods: Outcome (unparsed %)", "1.3–2.6%", rng(others, 1), "records (Phi, Yi, Falcon)")

# ---------- manipulation check ----------
acc = {m: R[KEY[m]]["manipulation_check_accuracy"] for m in KEY}
check("C1", "Abstract; Results (check)", "97–100%", rng([acc["Qwen"][f"core_N{n}"] for n in NS[1:]]),
      RJ + ": Qwen manipulation_check_accuracy core_N1..N999")
check("C2", "Results (check)", "47%", pct(acc["Qwen"]["core_N0"]), RJ + ": Qwen core_N0")
ans0 = collections.Counter(r["check_answer"] for r in REC["Qwen"] if r["cell"] == "core_N0")
check("C3", "Results (check): Qwen at N = 0 'often answered 3 or 4'", "3 or 4 most common wrong answers",
      f"3 or 4 most common wrong answers" if {a for a, _ in collections.Counter(
          {k: v for k, v in ans0.items() if k != 1}).most_common(2)} == {3, 4} else str(ans0.most_common(4)),
      f"records (Qwen) core_N0 check_answer: {dict(ans0.most_common(4))}")
check("C4", "Results (check)", "62% and 67%", f"{pct(acc['Yi']['core_N99'])} and {pct(acc['Falcon']['core_N99'])}",
      RJ + ": Yi, Falcon core_N99")
yiN = {n: sum(r["check_answer"] == n for r in REC["Yi"] if r["cell"] == f"core_N{n}") for n in [19, 99, 999]}
check("C5", "Results (check): Yi often answered N", "N given often at N = 19, 99, 999",
      "N given often at N = 19, 99, 999" if min(yiN.values()) >= 100 else str(yiN),
      f"records (Yi): answers equal to N: {yiN} of 480 each")
fnone = {n: sum(r["check_answer"] is None for r in REC["Falcon"] if r["cell"] == f"core_N{n}") for n in [19, 99, 999]}
fN = {n: sum(r["check_answer"] == n for r in REC["Falcon"] if r["cell"] == f"core_N{n}") for n in [19, 99, 999]}
check("C6", "Results (check): Falcon misses mostly unreadable",
      "unreadable > answered N", "unreadable > answered N" if all(fnone[n] > fN[n] for n in fnone) else "no",
      f"records (Falcon): unreadable {fnone}, answered N {fN}")
f1 = sum(r["check_answer"] == 3 for r in REC["Falcon"] if r["cell"] == "core_N1")
check("C7", "Table 3 caption: Falcon at N = 1 often answered 3", "often", "often" if f1 >= 100 else str(f1),
      f"records (Falcon) core_N1: answered 3 in {f1} of 480")
for i, m in enumerate(["Qwen", "Phi", "Yi", "Falcon"]):
    paper = {"Qwen": "47 97 98 100 100 100", "Phi": "3 37 27 11 13 14", "Yi": "54 99 95 49 62 10",
             "Falcon": "24 23 77 69 67 71"}[m]
    got = " ".join(q(acc[m][f"core_N{n}"], 0, 100) for n in NS)
    check(f"C8-{m}", "Table 3 row", paper, got, RJ + f": {m} manipulation_check_accuracy core cells")


def loose(m):
    out = []
    for n in NS[1:]:
        sub = [r for r in REC[m] if r["cell"] == f"core_N{n}"]
        out.append(sum(r["check_answer"] in (n, n + 1, n + 2) for r in sub) / len(sub))
    return rng(out)


for m, paper in [("Qwen", "98–100%"), ("Yi", "71–100%"), ("Falcon", "70–86%"), ("Phi", "11–37%")]:
    check(f"C9-{m}", "Table 3 caption (looser measure)", paper, loose(m),
          f"records ({m}): check_answer in N, N+1, N+2, core N >= 1")
check("C10", "What did not work; App. B item 4 (Phi re-check)", "12.9%", pct(acc["Phi"]["core_N99"], 1),
      RJ + ": Phi core_N99 (re-asked records)")

# ---------- Table 2 and H1 text ----------
T2 = {
    "H1 GEE slope": ("H1_gee_slope", coef, ["+0.024 [−0.017, +0.065]", "+0.002 [−0.061, +0.065]",
                                            "+0.079 [+0.021, +0.137]", "−0.032 [−0.096, +0.033]"]),
    "FE linear slope": ("H1_lpm_fixed_effects_slope", coef, ["+0.006 [−0.005, +0.016]",
                        "+0.000 [−0.015, +0.015]", "+0.020 [+0.004, +0.036]", "−0.007 [−0.023, +0.008]"]),
    "N=0 minus N=99": ("H1_N0_minus_N99", iv, ["−1.3 [−5.0, +2.5]", "+3.9 [−1.3, +8.6]",
                       "−4.9 [−9.9, −0.2]", "+2.4 [−2.0, +7.5]"]),
    "H2 interaction": ("H2_interaction", coef, ["−0.012 [−0.081, +0.057]", "−0.110 [−0.240, +0.021]",
                       "−0.120 [−0.262, +0.022]", "+0.179 [+0.022, +0.336]"]),
    "H3 desig N99 - core N0": ("H3_designated_N99_minus_core_N0", iv, ["+9.6 [+5.6, +13.6]", "−3.9 [−8.8, +1.5]",
                               "+14.2 [+9.2, +18.9]", "−1.1 [−6.1, +3.7]"]),
    "Desig - core, N99": ("H3_designated_N99_minus_core_N99", iv, ["+8.5 [+4.8, +12.1]", "+0.4 [−4.9, +5.8]",
                          "+9.4 [+4.1, +14.1]", "+1.1 [−4.1, +6.3]"]),
    "H4 board posts": ("H4_notool_board_posts_N99_minus_N0", iv, ["−1.7 [−5.8, +2.5]", "−4.4 [−9.4, +0.9]",
                       "+0.6 [−5.1, +6.4]", "−1.8 [−7.0, +3.5]"]),
}
for label, (k, fn, papers) in T2.items():
    for m, paper in zip(["Qwen", "Phi", "Yi", "Falcon"], papers):
        check(f"T2-{label}-{m}", f"Table 2: {label}", paper, fn(R[KEY[m]][k]), RJ + f": {m} {k}")
for m, paper in zip(["Qwen", "Phi", "Yi", "Falcon"], ["25.0% / 18.3%", "37.3% / 34.5%", "17.5% / 21.2%", "34.3% / 32.6%"]):
    fr = R[KEY[m]]["false_report_rate"]
    check(f"T2-false-{m}", "Table 2: false reports", paper,
          f"{pct(fr['twin_N0']['rate'], 1)} / {pct(fr['twin_N99']['rate'], 1)}", RJ + f": {m} false_report_rate")
vt = [R[KEY[m]]["check_violation_vs_twin_N0"]["diff"] for m in KEY]
check("R1", "Results: violations minus twins at N = 0", "27.5 to 37.4 points",
      f"{q(min(vt), 1, 100)} to {q(max(vt), 1, 100)} points", RJ + ": check_violation_vs_twin_N0")
check("R2", "Results H1: largest decline allowed", "2.5, 8.6, 7.5",
      ", ".join(q(R[KEY[m]]["H1_N0_minus_N99"]["ci95"][1], 1, 100) for m in ["Qwen", "Phi", "Falcon"]),
      RJ + ": upper bound of H1_N0_minus_N99 (Qwen, Phi, Falcon)")
check("R3", "Results H1: Yi reported more at N = 99", "4.9", q(-R[KEY["Yi"]]["H1_N0_minus_N99"]["diff"], 1, 100),
      RJ + ": Yi H1_N0_minus_N99")
lo = R[KEY["Qwen"]]["H1_N0_minus_N99"]["ci95"][0]
check("R4", "Results H1 / App. B 5: equivalence misses by", "0.01", q(abs(lo) * 100 - 5, 2),
      RJ + f": Qwen lower bound {lo} vs margin 0.05")
check("R5", "Results: H1 supported", "0 of 2 (and 0 of 2 added)",
      f"{sum(R[KEY[m]]['H1_supported'] for m in ['Qwen', 'Phi'])} of 2 (and "
      f"{sum(R[KEY[m]]['H1_supported'] for m in ['Yi', 'Falcon'])} of 2 added)", RJ + ": H1_supported")
check("R6", "Results H3: met for Qwen and Yi", "Qwen, Yi",
      ", ".join(m for m in KEY if R[KEY[m]]["H3_supported"]), RJ + ": H3_supported")
check("R7", "Results H3 text", "8.5 and 9.4",
      f"{q(R[KEY['Qwen']]['H3_designated_N99_minus_core_N99']['diff'], 1, 100)} and "
      f"{q(R[KEY['Yi']]['H3_designated_N99_minus_core_N99']['diff'], 1, 100)}", RJ + ": designated minus core N99")
core = {m: [R[KEY[m]]["cells"][f"core_N{n}"]["rate"] for n in NS] for m in KEY}
check("R8", "Discussion: Qwen 'within a few points of 63%'", "all six within 3 points of 63%",
      "all six within 3 points of 63%" if all(abs(v - 0.63) <= 0.03 for v in core["Qwen"]) else "no",
      RJ + f": Qwen core cells {rng(core['Qwen'], 1)}")
tw = [R[KEY[m]]["false_report_rate"][c]["rate"] for m in KEY for c in ["twin_N0", "twin_N99"]]
check("R9", "Discussion; App. D: harmless actions reported", "17–37%", rng(tw), RJ + ": false_report_rate")
dmax = max(v for m in KEY for v in R[KEY[m]]["deferral_word_rate"].values())
check("R10", "Discussion: deferring language at most", "1.3%", pct(dmax, 1), RJ + ": max deferral_word_rate")

# ---------- paired bootstrap (exploratory.py, same seed) ----------
def pd(m, a, b, key="reported", lo_pct=2.5, hi_pct=97.5):
    out = ex.paired_diff(ex.by_scenario(REC[m], a, key), ex.by_scenario(REC[m], b, key),
                         lo_pct=lo_pct, hi_pct=hi_pct)
    # exploratory.py returns "+0.067 [+0.031, +0.104] (scenarios=480)"; the paper rounds these strings
    est, lo_, hi_ = re.match(r"([+-][\d.]+) \[([+-][\d.]+), ([+-][\d.]+)\]", out).groups()
    return est, lo_, hi_


def pdstr(t):
    est, lo_, hi_ = t[0], t[1], t[2]
    return f"{q(est, 1, 100)} [{q(lo_, 1, 100)}, {q(hi_, 1, 100)}]"


for m, paper in [("Qwen", "10–13"), ("Phi", "13–19"), ("Yi", "38–50"), ("Falcon", "18–27")]:
    vals = [pd(m, f"silence_N{n}", f"core_N{n}")[0] for n in NS[1:]]
    check(f"X1-{m}", "Results H2–H4: silence line raised reporting by", paper,
          f"{q(min(vals), 0, 100)}–{q(max(vals), 0, 100)}", f"records ({m}): paired silence_N minus core_N")
check("X2", "Exploratory (i): Qwen false reports N0 minus N99", "6.7 [3.1, 10.4]",
      pdstr(pd("Qwen", "twin_N0", "twin_N99")), "records (Qwen): paired twin_N0 minus twin_N99")
check("X3", "Exploratory (ii): Phi dip N0 minus N1", "5.8 [0.6, 11.0]",
      pdstr(pd("Phi", "core_N0", "core_N1")), "records (Phi): paired core_N0 minus core_N1")
t90 = pd("Qwen", "core_N0", "core_N99", lo_pct=5, hi_pct=95)
check("X4", "App. B item 5: 90% interval", "[−4.4, +1.9]",
      f"[{q(t90[1], 1, 100, True)}, {q(t90[2], 1, 100, True)}]", "records (Qwen): paired core_N0 minus core_N99, 5-95%")
CELLS = {"core_N99", "core_N999", "silence_N99", "silence_N999", "notool_N99"}
pool = [r for m in KEY for r in REC[m] if r["cell"] in CELLS and r["parsed"]]
check("X5", "Exploratory (iii): keyword flags", "24 of 9,496",
      f"{sum(r['deferral_words'] for r in pool)} of {len(pool):,}", "records (all four): deferral_words, those cells")
RE_OTHERS = r"\b(other agents|others|\d{2,} agents|many agents|someone else|already)\b"
qm = [sum(bool(re.search(RE_OTHERS, r["reason"] or "", re.I)) for r in REC["Qwen"] if r["cell"] == c and r["parsed"])
      for c in ["core_N99", "core_N999"]]
check("X6", "Discussion: none of Qwen's reasons at N = 99, 999 mention others", "0 and 0", f"{qm[0]} and {qm[1]}",
      "records (Qwen): exploratory.py keyword regex")

# ---------- live boards ----------
L = json.load(open(args.live_summary))["models"]["Qwen/Qwen3-8B"]
inc = all(L["sizes"][s]["live_minus_prompt_only"]["ci95"][0] <= 0 <= L["sizes"][s]["live_minus_prompt_only"]["ci95"][1]
          for s in ["2", "5", "20"])
check("L1", "Exploratory (iv): live vs prompt-only, all intervals include zero", "yes", "yes" if inc else "no",
      "live_summary.json: sizes.*.live_minus_prompt_only")
check("L2", "Methods: live boards", "120 boards", f"{3 * L['sizes']['2']['any_report']['n']} boards",
      "live_summary.json: 40 scenarios x 3 sizes")
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    ex.live(args.live_records, args.qwen)
txt = buf.getvalue()
m1 = re.search(r"Boards where a post became visible: (\d+)\. Report rate before the first post (\d+)/(\d+) = ([\d.]+); "
               r"after it (\d+)/(\d+) = ([\d.]+); difference 95% CI over boards \[\+?([-\d.]+), \+?([-\d.]+)\]", txt)
check("L3", "Exploratory (iv): boards with a post", "17", m1.group(1), "live_records via exploratory.live()")
check("L4", "Exploratory (iv): before first post", "31% (11 of 35)", f"{pct(float(m1.group(4)))} ({m1.group(2)} of {m1.group(3)})",
      "live_records via exploratory.live()")
check("L5", "Exploratory (iv): after first post", "4% (6 of 156)", f"{pct(float(m1.group(7)))} ({m1.group(5)} of {m1.group(6)})",
      "live_records via exploratory.live()")
check("L6", "Exploratory (iv): difference over boards", "[10, 64]",
      f"[{q(m1.group(8), 0, 100)}, {q(m1.group(9), 0, 100)}]", "live_records via exploratory.live()")
m2 = re.search(r"scenarios whose boards got a post ([\d.]+)", txt)
check("L7", "Exploratory (iv): those scenarios' prompt-only rate", "43%", pct(float(m2.group(1))),
      "live_records + Qwen records via exploratory.live()")

with open(args.out, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "where in paper", "paper says", "recomputed", "result", "source"])
    w.writerows(rows)
bad = [r for r in rows if r[4] != "MATCH"]
for r in rows:
    print(f"{r[4]:9s} {r[0]:28s} paper: {r[2]:32s} recomputed: {r[3]}")
print(f"\n{len(rows)} checks, {len(rows) - len(bad)} MATCH, {len(bad)} MISMATCH. Written to {args.out}")
