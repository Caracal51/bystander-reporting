"""
Run one added model on a Modal H100: pilot -> gate.py -> main run only if the gate passes.
Run from a Kaggle cell (or any machine) after `pip install modal` and with
MODAL_TOKEN_ID / MODAL_TOKEN_SECRET set:

    modal run --detach modal_run.py --model Qwen/Qwen3-32B --tag qwen32b

The folder ./job must contain pilot_bystander.py, run_main.py, gate.py and scenarios.jsonl.
Outputs are written to the Modal volume "bystander-out" as <tag>_outputs.zip and, if this
client is still connected at the end, also to ./modal_<tag>_outputs.zip.
Fetch later with:  modal volume get bystander-out <tag>_outputs.zip .
"""
import io
import os
import subprocess
import zipfile

import modal

JOB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "job")

image = (
    modal.Image.from_registry("nvidia/cuda:12.8.1-devel-ubuntu22.04", add_python="3.11")
    .pip_install("vllm", "numpy")
    .env({"BYSTANDER_DTYPE": "bfloat16", "VLLM_USE_FLASHINFER_SAMPLER": "0"})
    .add_local_dir(JOB_DIR, remote_path="/root/job")
)
app = modal.App("bystander-added-model", image=image)
hf_cache = modal.Volume.from_name("bystander-hf-cache", create_if_missing=True)
out_vol = modal.Volume.from_name("bystander-out", create_if_missing=True)


@app.function(gpu="H100", timeout=4 * 3600,
              volumes={"/root/.cache/huggingface": hf_cache, "/out": out_vol})
def run(model: str, tag: str) -> bytes:
    os.chdir("/root/job")

    def sh(cmd):
        print(f"\n$ {cmd}", flush=True)
        return subprocess.run(cmd, shell=True).returncode

    common = f"--model {model} --tp 1 --gpu-mem 0.92 --check-max-tokens 120"
    sh(f"python pilot_bystander.py {common} --out pilot_out_{tag}")
    ran_main = False
    if os.path.exists(f"pilot_out_{tag}/pilot_records.jsonl"):
        if sh(f"python gate.py pilot_out_{tag}") == 0:
            sh(f"python run_main.py {common} --scenarios scenarios.jsonl --out main_out_{tag}")
            ran_main = True
    else:
        print("Pilot did not finish (gated, or the model failed to load).")
    hf_cache.commit()

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for folder in (f"pilot_out_{tag}", f"main_out_{tag}"):
            for root, _, files in os.walk(folder):
                for name in files:
                    path = os.path.join(root, name)
                    z.write(path, path)
    data = buf.getvalue()
    with open(f"/out/{tag}_outputs.zip", "wb") as f:
        f.write(data)
    out_vol.commit()
    print(f"\nSaved /out/{tag}_outputs.zip ({len(data)} bytes); main run {'done' if ran_main else 'not run'}.")
    return data


@app.local_entrypoint()
def main(model: str = "Qwen/Qwen3-32B", tag: str = "qwen32b"):
    data = run.remote(model, tag)
    path = f"modal_{tag}_outputs.zip"
    with open(path, "wb") as f:
        f.write(data)
    print(f"Wrote {path}")
