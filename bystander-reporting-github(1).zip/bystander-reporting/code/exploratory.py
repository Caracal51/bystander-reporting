"""
Exploratory (not preregistered) analyses of the bystander-study outputs.
Run from the folder that holds main_out/ and live_out/:
    python exploratory.py > exploratory_results.txt
Every number here is post hoc and should be reported as exploratory.
"""
import collections
import glob
import json
import random
import re


def load(path):
    return [json.loads(line) for line in open(path)]


def by_scenario(rs, cell, key="reported"):
    return {r["scenario"]: int(r[key]) for r in rs if r["cell"] == cell and r["parsed"]}


def paired_diff(a, b, B=4000, seed=0, lo_pct=2.5, hi_pct=97.5):
    ks = sorted(set(a) & set(b))
    rng = random.Random(seed)
    est = sum(a[k] for k in ks) / len(ks) - sum(b[k] for k in ks) / len(ks)
    boots = []
    for _ in range(B):
        s = [ks[rng.randrange(len(ks))] for _ in ks]
        boots.append(sum(a[k] for k in s) / len(s) - sum(b[k] for k in s) / len(s))
    boots.sort()
    return f"{est:+.3f} [{boots[int(lo_pct / 100 * B)]:+.3f}, {boots[int(hi_pct / 100 * B) - 1]:+.3f}] (scenarios={len(ks)})"


def main_run(path):
    rs = load(path)
    print(f"\n===== {rs[0]['model']}  ({path})")
    print("N0 minus N99, core, 90% interval (two one-sided tests at 5%):",
          paired_diff(by_scenario(rs, "core_N0"), by_scenario(rs, "core_N99"), lo_pct=5, hi_pct=95))
    print("N0 minus N1, core:", paired_diff(by_scenario(rs, "core_N0"), by_scenario(rs, "core_N1")))
    print("False reports, twin N0 minus twin N99:", paired_diff(by_scenario(rs, "twin_N0"), by_scenario(rs, "twin_N99")))
    for n in (1, 4, 19, 99, 999):
        print(f"silence_N{n} minus core_N{n}:", paired_diff(by_scenario(rs, f"silence_N{n}"), by_scenario(rs, f"core_N{n}")))
    print("designated_N0 minus core_N0:", paired_diff(by_scenario(rs, "designated_N0"), by_scenario(rs, "core_N0")))
    sev = {r["scenario"]: r["severity"] for r in rs}
    for s in ("minor", "moderate", "serious"):
        def rate(cells):
            xs = [r["reported"] for r in rs if r["parsed"] and r["cell"] in cells and sev[r["scenario"]] == s]
            return f"{sum(xs) / len(xs):.3f} (n={len(xs)})"
        print(f"  severity {s:8s}: core N0 {rate({'core_N0'})}; core N99+N999 {rate({'core_N99', 'core_N999'})}; "
              f"twin N0 {rate({'twin_N0'})}")
    for cell in ("core_N99", "core_N999"):
        sub = [r for r in rs if r["cell"] == cell and r["parsed"]]
        m = sum(bool(re.search(r"\b(other agents|others|\d{2,} agents|many agents|someone else|already)\b",
                               r["reason"], re.I)) for r in sub)
        print(f"{cell}: reasons that mention other agents or 'already': {m} of {len(sub)}")
    print("Registered the number (exploratory, looser than the preregistered check): answer equals N "
          "(others), N + 1 (including self) or N + 2 (also counting the peer):")
    for cell in ("core_N0", "core_N1", "core_N4", "core_N19", "core_N99", "core_N999"):
        sub = [r for r in rs if r["cell"] == cell]
        ok = sum(r["check_answer"] in (r["n_others"], r["n_others"] + 1, r["n_others"] + 2) for r in sub)
        print(f"  {cell}: {ok}/{len(sub)} = {ok / len(sub):.1%}")
    print("Follow-up answers that are a bare number, and how many are correct (n_others + 1):")
    for cell in ("core_N0", "core_N1", "core_N4", "core_N19", "core_N99", "core_N999"):
        sub = [r for r in rs if r["cell"] == cell]
        bare = [r for r in sub if re.fullmatch(r"\s*\d+\s*", r["check_raw"])]
        ok = sum(int(r["check_raw"].strip()) == r["n_others"] + 1 for r in bare)
        print(f"  {cell}: bare number {len(bare)}/{len(sub)}, correct {ok}; "
              f"most common raw: {collections.Counter(r['check_raw'].strip()[:40] for r in sub).most_common(2)}")


def live(path, main_path):
    rs = load(path)
    print(f"\n===== Live boards ({path})")
    boards = collections.defaultdict(list)
    for r in rs:
        boards[r["board"]].append(r)
    for v in boards.values():
        v.sort(key=lambda r: r["position"])
    has_post = lambda v: any(r["posted"] and r["post_message"] for r in v)
    nopost20 = [v for v in boards.values() if not has_post(v) and v[0]["board_size"] == 20]
    early = [r["reported"] for v in nopost20 for r in v[:5]]
    late = [r["reported"] for v in nopost20 for r in v[5:]]
    print(f"20-agent boards with no post ({len(nopost20)}): report rate positions 1-5 {sum(early) / len(early):.3f}, "
          f"positions 6-20 {sum(late) / len(late):.3f}")
    rows = []
    for v in boards.values():
        fp = next((i for i, r in enumerate(v) if r["posted"] and r["post_message"]), None)
        if fp is None:
            continue
        pre, post = v[:fp], v[fp + 1:]
        rows.append((sum(r["reported"] for r in pre), len(pre), sum(r["reported"] for r in post), len(post)))
    a, na = sum(x[0] for x in rows), sum(x[1] for x in rows)
    b, nb = sum(x[2] for x in rows), sum(x[3] for x in rows)
    rng = random.Random(0)
    diffs = []
    for _ in range(5000):
        s = [rows[rng.randrange(len(rows))] for _ in rows]
        sa, sna, sb, snb = (sum(x[i] for x in s) for i in range(4))
        if sna and snb:
            diffs.append(sa / sna - sb / snb)
    diffs.sort()
    print(f"Boards where a post became visible: {len(rows)}. Report rate before the first post {a}/{na} = {a / na:.3f}; "
          f"after it {b}/{nb} = {b / nb:.3f}; difference 95% CI over boards "
          f"[{diffs[int(.025 * len(diffs))]:+.3f}, {diffs[int(.975 * len(diffs))]:+.3f}]")
    after = collections.Counter(r["tool"] for v in boards.values()
                                for i, r in enumerate(v)
                                if (fp := next((j for j, x in enumerate(v) if x["posted"] and x["post_message"]), None)) is not None and i > fp)
    print("Tools chosen after the first post:", dict(after))
    posts = [r["post_message"] for r in rs if r["posted"] and r["post_message"]]
    claims = sum(bool(re.search(r"report|overseer|flag", p, re.I)) for p in posts)
    print(f"Posts: {len(posts)}; posts mentioning report/overseer/flag: {claims}; most repeated: "
          f"{collections.Counter(posts).most_common(1)}")
    main = load(main_path)
    core = [r for r in main if r["cell"].startswith("core") and r["parsed"]]
    per = collections.defaultdict(list)
    for r in core:
        per[r["scenario"]].append(r["reported"])
    post_scn = {v[0]["scenario"] for v in boards.values() if has_post(v)}
    live_scn = {v[0]["scenario"] for v in boards.values()}
    xs = [x for s in post_scn for x in per[s]]
    ys = [x for s in live_scn - post_scn for x in per[s]]
    print(f"Prompt-only core-cell report rate: scenarios whose boards got a post {sum(xs) / len(xs):.3f} (n={len(xs)}); "
          f"other live scenarios {sum(ys) / len(ys):.3f} (n={len(ys)})")
    for B in (2, 5, 20):
        obs = [any(r["reported"] for r in v) for v in boards.values() if v[0]["board_size"] == B]
        pred = [1 - (1 - sum(per[s]) / len(per[s])) ** B for s in live_scn]
        print(f"Board size {B}: at least one report observed {sum(obs) / len(obs):.3f}; predicted from each scenario's "
              f"own prompt-only rate {sum(pred) / len(pred):.3f} (the summary's 'independent agents' column ignores "
              f"that agents on one board share a scenario)")


def recheck(path):
    rs = load(path)
    print(f"\n===== Re-asked check ({path}), max_tokens={rs[0].get('check_max_tokens')}")
    print("cell: gave a number | correct among numbers | report rate if check passed | if not passed")
    for cell in ("core_N0", "core_N1", "core_N4", "core_N19", "core_N99", "core_N999"):
        sub = [r for r in rs if r["cell"] == cell and r["parsed"]]
        num = [r for r in sub if r["check_answer"] is not None]
        ok = [r for r in sub if r["check_correct"]]
        no = [r for r in sub if not r["check_correct"]]
        rate = lambda xs: f"{sum(r['reported'] for r in xs) / len(xs):.3f} (n={len(xs)})" if xs else "n/a"
        print(f"  {cell}: {len(num) / len(sub):.3f} | {len(ok)}/{len(num)} | {rate(ok)} | {rate(no)}")
    allc = [r for r in rs if r["cell"] == "core_N99"]
    k = sum(r["check_correct"] for r in allc)
    print(f"Rule fixed before re-asking: core_N99 accuracy >= 50%. Observed {k}/{len(allc)} = {k / len(allc):.1%}.")
    odd = collections.Counter(r["check_answer"] for r in rs
                              if r["check_answer"] is not None and r["check_answer"] not in (1, 2, 5, 10, 20, 100, 1000))
    print("Other numbers picked up (ports, ids):", dict(odd.most_common(8)))
    for cell in ("notool_N0", "notool_N99"):
        sub = [r for r in rs if r["cell"] == cell]
        print(f"{cell}: answers {dict(collections.Counter(r['check_answer'] for r in sub).most_common(5))} (n={len(sub)})")


if __name__ == "__main__":
    for p in sorted(glob.glob("main_out/records_*.jsonl")):
        main_run(p)
    for p in sorted(glob.glob("live_out/live_records_*.jsonl")):
        model_slug = p.split("live_records_")[1]
        live(p, f"main_out/records_{model_slug}")
    for p in sorted(glob.glob("main_out_recheck/records_*.jsonl")):
        recheck(p)
