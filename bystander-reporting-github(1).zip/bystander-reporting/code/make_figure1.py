"""Figure 1: core-cell report rate against N, one line per model, from results.json."""
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

RESULTS = sys.argv[1] if len(sys.argv) > 1 else "/tmp/amz/x/results_v3/results.json"
OUT = sys.argv[2] if len(sys.argv) > 2 else "figure1.png"

for f in ["/root/.fonts/OldStandard-Regular.ttf", "/root/.fonts/OldStandard-Bold.ttf",
          "/root/.fonts/OldStandard-Italic.ttf"]:
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "Old Standard TT", "font.size": 9.5,
                     "axes.spines.top": False, "axes.spines.right": False})

r = json.load(open(RESULTS))["models"]
NS = [0, 1, 4, 19, 99, 999]
# (key in results.json, label, colour, marker, line width, dodge)
MODELS = [
    ("Qwen/Qwen3-8B", "Qwen3-8B", "#1f5fbf", "o", 2.2, -0.045),
    ("microsoft/Phi-4-mini-instruct", "Phi-4-mini", "#555555", "s", 1.2, -0.015),
    ("tiiuae/Falcon3-7B-Instruct", "Falcon3-7B (added)", "#8a8a8a", "D", 1.2, 0.015),
    ("01-ai/Yi-1.5-9B-Chat", "Yi-1.5-9B (added)", "#a8a8a8", "^", 1.2, 0.045),
]

fig, ax = plt.subplots(figsize=(6.5, 2.75), dpi=300)
x = np.log10(np.array(NS) + 1)
ends = []
for key, label, colour, marker, lw, dodge in MODELS:
    cells = r[key]["cells"]
    rate = np.array([cells[f"core_N{n}"]["rate"] for n in NS]) * 100
    lo = np.array([cells[f"core_N{n}"]["ci95"][0] for n in NS]) * 100
    hi = np.array([cells[f"core_N{n}"]["ci95"][1] for n in NS]) * 100
    xs = x + dodge
    ax.errorbar(xs, rate, yerr=[rate - lo, hi - rate], fmt="none", ecolor=colour,
                elinewidth=0.9, capsize=0, zorder=2)
    ax.plot(xs, rate, color=colour, lw=lw, marker=marker, ms=4.2 if key.startswith("Qwen") else 3.6,
            zorder=3 if key.startswith("Qwen") else 2)
    ends.append([rate[-1], label, colour, xs[-1]])

# direct labels at the right, nudged apart so none overlap
ends.sort(key=lambda e: -e[0])
placed = []
for val, label, colour, xe in ends:
    y = val
    if placed and placed[-1] - y < 3.2:
        y = placed[-1] - 3.2
    placed.append(y)
    ax.annotate(label, xy=(xe, val), xytext=(3.17, y), textcoords="data", va="center", fontsize=9,
                color=colour if "Qwen" in label else "#333333",
                fontweight="bold" if "Qwen" in label else "normal",
                arrowprops=dict(arrowstyle="-", color="#bbbbbb", lw=0.6, shrinkA=0, shrinkB=3))

ax.set_xticks(x)
ax.set_xticklabels([str(n) for n in NS])
ax.set_xlim(-0.12, 3.12)
ax.set_ylim(30, 80)
ax.set_yticks([30, 40, 50, 60, 70, 80])
ax.set_yticklabels([f"{v}%" for v in [30, 40, 50, 60, 70, 80]])
ax.grid(axis="y", color="#e6e6e6", lw=0.6)
ax.set_axisbelow(True)
ax.set_xlabel("Other agents shown as having seen the violation, N (axis spaced by log10(N + 1))")
ax.set_ylabel("Decisions reporting to overseer")
fig.subplots_adjust(left=0.1, right=0.78, top=0.97, bottom=0.19)
fig.savefig(OUT, dpi=300)
print("wrote", OUT)
