"""Format every table value in the submission straight from results.json, so nothing is retyped."""
import json
import sys

RESULTS = sys.argv[1] if len(sys.argv) > 1 else "/tmp/amz/x/results_v3/results.json"
OUT = sys.argv[2] if len(sys.argv) > 2 else "report_values.json"
r = json.load(open(RESULTS))["models"]
ORDER = ["Qwen/Qwen3-8B", "microsoft/Phi-4-mini-instruct", "01-ai/Yi-1.5-9B-Chat",
         "tiiuae/Falcon3-7B-Instruct"]
NS = [0, 1, 4, 19, 99, 999]


from decimal import Decimal, ROUND_HALF_UP


def fmt(v, dp, scale=1):
    """Round the stored value half-up (results.json keeps 4 decimals); use a real minus sign."""
    q = (Decimal(str(v)) * scale).quantize(Decimal(1).scaleb(-dp), rounding=ROUND_HALF_UP)
    return (("+" if q >= 0 else "") + str(q)).replace("-", "−")


def slope(d, dp=3):
    s = lambda v: fmt(v, dp)
    return f"{s(d['coef'])} [{s(d['ci95'][0])}, {s(d['ci95'][1])}]"


def pts(d):
    s = lambda v: fmt(v, 1, 100)
    return f"{s(d['diff'])} [{s(d['ci95'][0])}, {s(d['ci95'][1])}]"


rows = [
    ("H1: logistic GEE slope (log-odds)", lambda m: slope(m["H1_gee_slope"])),
    ("H1 robustness: fixed-effects linear slope", lambda m: slope(m["H1_lpm_fixed_effects_slope"])),
    ("N = 0 minus N = 99 (points)", lambda m: pts(m["H1_N0_minus_N99"])),
    ("H2: silence × N interaction (log-odds)", lambda m: slope(m["H2_interaction"])),
    ("H3: designated N = 99 minus core N = 0 (points)", lambda m: pts(m["H3_designated_N99_minus_core_N0"])),
    ("Designated minus core, both N = 99 (points)", lambda m: pts(m["H3_designated_N99_minus_core_N99"])),
    ("H4: board posts without report tool, N = 99 minus N = 0 (points)",
     lambda m: pts(m["H4_notool_board_posts_N99_minus_N0"])),
    ("Violations minus harmless twins, N = 0 (points)", lambda m: pts(m["check_violation_vs_twin_N0"])),
    ("False reports on twins, N = 0 / N = 99",
     lambda m: f"{m['false_report_rate']['twin_N0']['rate'] * 100:.1f}% / "
               f"{m['false_report_rate']['twin_N99']['rate'] * 100:.1f}%"),
]
table2 = [[label] + [fn(r[k]) for k in ORDER] for label, fn in rows]

check = []
for k in ORDER:
    acc = r[k]["manipulation_check_accuracy"]
    check.append([f"{acc[f'core_N{n}'] * 100:.0f}%" for n in NS])

core = {k: [r[k]["cells"][f"core_N{n}"]["rate"] for n in NS] for k in ORDER}
unparsed = {k: sum(r[k]["unparsed_by_cell"].values()) for k in ORDER}
json.dump({"table2": table2, "check": check, "core": core, "unparsed": unparsed,
           "decisions": {k: r[k]["decisions"] for k in ORDER}}, open(OUT, "w"), ensure_ascii=False,
          indent=1)
for row in table2:
    print(" | ".join(row))
print(check)
print(unparsed)
