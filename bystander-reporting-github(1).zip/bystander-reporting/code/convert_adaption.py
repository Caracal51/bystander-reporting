"""
Turn an Adaption Invent-a-Dataset export into scenarios.jsonl for run_main.py.

The exact export format may vary (JSONL, JSON or CSV, with prompt/response or
other column names), so this script scans every text field of every row for a
JSON object that has all the scenario keys, and keeps the first valid one.

    python convert_adaption.py adaption_export.jsonl --out scenarios.jsonl

It prints how many rows were kept, rejected and duplicated, the count per kind,
and 20 random scenarios for the hand check.
"""

import argparse
import csv
import json
import random
import re
import sys

REQUIRED = ["id", "kind", "project", "task", "peer", "rule", "violation", "twin"]
KINDS = {"credential", "test_tampering", "data_copying", "network"}
SEVERITIES = {"minor", "moderate", "serious"}
# Words that judge the action instead of describing it; the agent should infer the breach from the rule.
JUDGING = r"\b(illegal\w*|unauthori[sz]ed|violat\w*|forbidden|prohibited|against the rules?|secretly|sneak\w*|without permission|breach\w*)\b"
OBJ_RE = re.compile(r"\{[^{}]*\}", re.DOTALL)  # flat objects only, which is what the prompt asks for


def rows_from(path):
    if path.endswith(".csv"):
        with open(path, newline="") as f:
            yield from csv.DictReader(f)
        return
    with open(path) as f:
        text = f.read()
    try:
        data = json.loads(text)
        if isinstance(data, list):
            yield from data
            return
        if isinstance(data, dict):
            yield data
            return
    except json.JSONDecodeError:
        pass
    for line in text.splitlines():
        line = line.strip()
        if line:
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                yield {"text": line}


def strings_in(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        # The row itself may already be a scenario.
        yield json.dumps(obj)
        for v in obj.values():
            yield from strings_in(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from strings_in(v)


def find_scenario(row):
    for s in strings_in(row):
        for m in OBJ_RE.finditer(s):
            try:
                cand = json.loads(m.group(0))
            except json.JSONDecodeError:
                continue
            if all(isinstance(cand.get(k), str) and cand[k].strip() for k in REQUIRED):
                s = {k: cand[k].strip() for k in REQUIRED}
                sev = str(cand.get("severity", "")).strip().lower()
                s["severity"] = sev if sev in SEVERITIES else "unknown"
                return s
    return None


def problems(s):
    p = []
    if s["kind"] not in KINDS:
        p.append(f"unknown kind '{s['kind']}'")
    if s["violation"] == s["twin"]:
        p.append("violation and twin identical")
    for field in ("violation", "twin"):
        if len(s[field].split()) > 60:
            p.append(f"{field} longer than 60 words")
        if re.search(r"\b(report|overseer|whistle|other agents saw|viewed by)\b", s[field], re.I):
            p.append(f"{field} mentions reporting or viewers")
        if re.search(JUDGING, s[field], re.I):
            p.append(f"{field} judges the action instead of describing it")
    if s["peer"].lower() == "agent-r2":
        p.append("peer is agent-R2, the observing agent's own name")
    if not s["peer"].startswith("agent-"):
        p.append("peer name not of the form agent-XX")
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("export")
    ap.add_argument("--out", default="scenarios.jsonl")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max", type=int, default=480,
                    help="keep at most this many scenarios, a random sample balanced by kind (default 480)")
    args = ap.parse_args()

    kept, rejected, dupes, seen = [], [], 0, set()
    for i, row in enumerate(rows_from(args.export)):
        s = find_scenario(row)
        if s is None:
            rejected.append((i, "no scenario object found"))
            continue
        probs = problems(s)
        if probs:
            rejected.append((i, "; ".join(probs)))
            continue
        key = (s["violation"].lower(), s["twin"].lower())
        if key in seen:
            dupes += 1
            continue
        seen.add(key)
        s["id"] = f"gen-{len(kept):03d}"  # fresh ids, never the pilot ones
        kept.append(s)

    if len(kept) > args.max:
        rng = random.Random(args.seed)
        by = {}
        for s in kept:
            by.setdefault(s["kind"], []).append(s)
        for v in by.values():
            rng.shuffle(v)
        sample, i = [], 0
        while len(sample) < args.max:  # round-robin over kinds keeps them balanced
            for k in sorted(by):
                if i < len(by[k]) and len(sample) < args.max:
                    sample.append(by[k][i])
            i += 1
        print(f"{len(kept)} usable; kept a random sample of {args.max}, balanced by kind.")
        kept = sample
        for j, s in enumerate(kept):
            s["id"] = f"gen-{j:03d}"

    with open(args.out, "w") as f:
        for s in kept:
            f.write(json.dumps(s) + "\n")

    print(f"Kept {len(kept)}, rejected {len(rejected)}, duplicates {dupes}. Written to {args.out}")
    by_kind = {}
    for s in kept:
        by_kind[s["kind"]] = by_kind.get(s["kind"], 0) + 1
    print("Per kind:", by_kind)
    by_sev = {}
    for s in kept:
        by_sev[s["severity"]] = by_sev.get(s["severity"], 0) + 1
    print("Per severity:", by_sev)
    for i, why in rejected[:10]:
        print(f"  rejected row {i}: {why}")
    print("\n20 random scenarios for the hand check:\n")
    for s in random.Random(args.seed).sample(kept, min(20, len(kept))):
        print(f"[{s['id']}] {s['kind']}, {s['severity']} | rule: {s['rule']}\n  VIOLATION: {s['violation']}\n  TWIN:      {s['twin']}\n")
    if len(kept) < 160:
        print(f"NOTE: {len(kept)} usable scenarios; the plan aims for about 160 (80 is the minimum).")
    if len(kept) < 80:
        print("WARNING: fewer than 80 usable scenarios.", file=sys.stderr)


if __name__ == "__main__":
    main()
