"""Re-derive the H1 test's false-positive rate under no effect, from real data.

For each of --sims datasets, take Qwen3-8B's real core-cell decisions and shuffle the
N labels within each scenario (so there is no true effect of N, but each scenario keeps
its own report rate). Fit the preregistered logistic GEE (report ~ log10(N+1),
exchangeable within scenario) and count how often the slope's 95% interval lies
entirely below zero (a false "bystander effect"). Expected about 2.5%.

    python sim_null.py main_out/records_Qwen_Qwen3_8B.jsonl --sims 200
"""
import argparse
import json
import random
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

warnings.filterwarnings("ignore")
ap = argparse.ArgumentParser()
ap.add_argument("records")
ap.add_argument("--sims", type=int, default=200)
ap.add_argument("--seed", type=int, default=0)
args = ap.parse_args()

rows = [json.loads(l) for l in open(args.records)]
core = [r for r in rows if r["cell"].startswith("core_") and r["parsed"]]
df = pd.DataFrame({"scenario": [r["scenario"] for r in core],
                   "n": [r["n_others"] for r in core],
                   "report": [int(r["reported"]) for r in core]})
rng = random.Random(args.seed)
below = 0
for s in range(args.sims):
    d = df.copy()
    d["n"] = d.groupby("scenario")["n"].transform(lambda x: rng.sample(list(x), len(x)))
    d["x"] = np.log10(d["n"] + 1)
    fit = smf.gee("report ~ x", "scenario", d, family=sm.families.Binomial(),
                  cov_struct=sm.cov_struct.Exchangeable()).fit()
    hi = fit.conf_int().loc["x", 1]
    below += hi < 0
    if (s + 1) % 50 == 0:
        print(f"{s + 1} datasets: {below} with the 95% interval below zero", flush=True)
print(f"FINAL: {below}/{args.sims} = {below / args.sims:.1%} false positives (one-sided)")
