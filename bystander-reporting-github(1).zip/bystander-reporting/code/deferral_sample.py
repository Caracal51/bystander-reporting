"""Draw the deferral hand-check sample: reasons from the core, silence and no-tool cells at
N = 99 and 999 (all four models), 10 flagged by the keyword list and 40 not flagged.
Writes a CSV with an empty column for your own judgement.

    python deferral_sample.py main_out/records_*.jsonl --out deferral_handcheck.csv
"""
import argparse
import csv
import glob
import json
import random

ap = argparse.ArgumentParser()
ap.add_argument("records", nargs="+")
ap.add_argument("--out", default="deferral_handcheck.csv")
ap.add_argument("--seed", type=int, default=0)
args = ap.parse_args()

CELLS = {"core_N99", "core_N999", "silence_N99", "silence_N999", "notool_N99"}
flag, noflag = [], []
for pat in args.records:
    for path in sorted(glob.glob(pat)):
        for line in open(path):
            r = json.loads(line)
            if r["cell"] in CELLS and r["parsed"]:
                (flag if r["deferral_words"] else noflag).append(r)
print(f"pool: {len(flag)} flagged, {len(noflag)} not flagged, {len(flag) + len(noflag)} total")
rng = random.Random(args.seed)
pick = rng.sample(flag, 10) + rng.sample(noflag, 40)
rng.shuffle(pick)  # mixed, so the reader does not know which were flagged
with open(args.out, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["row", "model", "scenario", "cell", "tool", "reason",
                "defers_to_others (fill in yes/no)", "keyword_flag (look only after judging)"])
    for i, r in enumerate(pick, 1):
        w.writerow([i, r["model"], r["scenario"], r["cell"], r["tool"], r["reason"], "",
                    "flagged" if r["deferral_words"] else "not flagged"])
print("wrote", args.out)
