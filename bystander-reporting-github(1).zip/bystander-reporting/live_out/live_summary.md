# Live-board check (exploratory)

## Qwen/Qwen3-8B

1080 agent turns, parse rate 100.0%.

Prompt-only rates use the same scenarios as the live boards.

| Others | Live: report rate per agent | Prompt-only at same N | Live minus prompt-only | Boards with at least one report | If agents were independent | Check correct |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 0.637 [0.500, 0.775] | 0.725 [0.575, 0.851] | -0.087 [-0.212, +0.013] | 0.725 [0.575, 0.850] | 0.924 | 100.0% |
| 4 | 0.700 [0.585, 0.820] | 0.675 [0.525, 0.801] | +0.025 [-0.070, +0.125] | 0.850 [0.725, 0.950] | 0.996 | 100.0% |
| 19 | 0.610 [0.485, 0.744] | 0.625 [0.475, 0.775] | -0.015 [-0.116, +0.072] | 0.900 [0.800, 0.975] | 1.000 | 100.0% |

Agents who had seen at least one earlier post vs none (descriptive; confounded with position):

- 1 other: saw posts 0.000 [0.000, 0.000] (n=3); saw none 0.662 [0.525, 0.792] (n=77); board post rate 0.062 [0.013, 0.138]
- 4 others: saw posts 0.143 [0.000, 0.462] (n=14); saw none 0.742 [0.634, 0.848] (n=186); board post rate 0.055 [0.005, 0.125]
- 19 others: saw posts 0.029 [0.000, 0.080] (n=139); saw none 0.732 [0.619, 0.843] (n=661); board post rate 0.084 [0.024, 0.158]

