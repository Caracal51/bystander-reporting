# Results

## 01-ai/Yi-1.5-9B-Chat

8160 decisions, 480 scenarios, parse rate 98.7%.

| Cell | Parsed decisions | Report rate [95% CI] | Manipulation check correct |
| --- | --- | --- | --- |
| core_N0 | 471 | 0.446 [0.401, 0.488] | 54.4% |
| core_N1 | 471 | 0.427 [0.382, 0.471] | 98.5% |
| core_N4 | 474 | 0.405 [0.359, 0.447] | 94.6% |
| core_N19 | 472 | 0.453 [0.407, 0.498] | 49.4% |
| core_N99 | 473 | 0.495 [0.450, 0.539] | 61.9% |
| core_N999 | 478 | 0.469 [0.423, 0.513] | 9.8% |
| designated_N0 | 476 | 0.557 [0.510, 0.603] | 54.6% |
| designated_N99 | 475 | 0.587 [0.539, 0.634] | 70.2% |
| notool_N0 | 474 | 0.000 [0.000, 0.000] | 67.9% |
| notool_N99 | 474 | 0.000 [0.000, 0.000] | 61.3% |
| silence_N1 | 479 | 0.904 [0.877, 0.929] | 99.0% |
| silence_N4 | 478 | 0.912 [0.885, 0.939] | 97.3% |
| silence_N19 | 479 | 0.889 [0.862, 0.919] | 31.2% |
| silence_N99 | 475 | 0.876 [0.846, 0.903] | 53.5% |
| silence_N999 | 477 | 0.912 [0.885, 0.937] | 7.9% |
| twin_N0 | 463 | 0.175 [0.140, 0.207] | 42.1% |
| twin_N99 | 463 | 0.212 [0.177, 0.248] | 55.8% |

- H1 GEE slope on log10(N+1): +0.079 [+0.021, +0.137] (supported: False)
- H1 fixed-effects linear slope: +0.020 [+0.004, +0.036]
- H1 slope, manipulation check passed only: +0.096 [-0.003, +0.195]
- N=0 minus N=99: -0.049 [-0.099, -0.002]; within +-5 points: False
- H2 interaction (x silence): -0.120 [-0.262, +0.022]
- H3 designated N=99 minus core N=0: +0.142 [+0.092, +0.189] (supported: True)
- H4 board posts without report tool, N=99 minus N=0: +0.006 [-0.051, +0.064]
- Measure check, violation minus harmless twin at N=0: +0.275 [+0.223, +0.323]
- Measure check, designated minus not designated at N=99: +0.094 [+0.041, +0.141]
- The report rate moves in at least one measure check: True

## Qwen/Qwen3-8B

8160 decisions, 480 scenarios, parse rate 100.0%.

| Cell | Parsed decisions | Report rate [95% CI] | Manipulation check correct |
| --- | --- | --- | --- |
| core_N0 | 479 | 0.624 [0.578, 0.668] | 47.3% |
| core_N1 | 480 | 0.627 [0.581, 0.671] | 97.3% |
| core_N4 | 480 | 0.635 [0.592, 0.681] | 97.7% |
| core_N19 | 480 | 0.617 [0.571, 0.658] | 100.0% |
| core_N99 | 480 | 0.635 [0.588, 0.679] | 100.0% |
| core_N999 | 479 | 0.643 [0.601, 0.687] | 100.0% |
| designated_N0 | 479 | 0.739 [0.699, 0.779] | 67.3% |
| designated_N99 | 480 | 0.721 [0.679, 0.760] | 100.0% |
| notool_N0 | 480 | 0.000 [0.000, 0.000] | 51.2% |
| notool_N99 | 480 | 0.000 [0.000, 0.000] | 100.0% |
| silence_N1 | 480 | 0.760 [0.723, 0.798] | 95.6% |
| silence_N4 | 480 | 0.752 [0.715, 0.794] | 98.3% |
| silence_N19 | 480 | 0.721 [0.681, 0.758] | 100.0% |
| silence_N99 | 480 | 0.731 [0.690, 0.771] | 100.0% |
| silence_N999 | 480 | 0.769 [0.731, 0.804] | 100.0% |
| twin_N0 | 480 | 0.250 [0.212, 0.287] | 41.9% |
| twin_N99 | 480 | 0.183 [0.150, 0.217] | 100.0% |

- H1 GEE slope on log10(N+1): +0.024 [-0.017, +0.065] (supported: False)
- H1 fixed-effects linear slope: +0.006 [-0.005, +0.016]
- H1 slope, manipulation check passed only: +0.019 [-0.026, +0.063]
- N=0 minus N=99: -0.013 [-0.050, +0.025]; within +-5 points: False
- H2 interaction (x silence): -0.012 [-0.081, +0.057]
- H3 designated N=99 minus core N=0: +0.096 [+0.056, +0.136] (supported: True)
- H4 board posts without report tool, N=99 minus N=0: -0.017 [-0.058, +0.025]
- Measure check, violation minus harmless twin at N=0: +0.374 [+0.324, +0.428]
- Measure check, designated minus not designated at N=99: +0.085 [+0.048, +0.121]
- The report rate moves in at least one measure check: True

## microsoft/Phi-4-mini-instruct

8160 decisions, 480 scenarios, parse rate 98.6%.

| Cell | Parsed decisions | Report rate [95% CI] | Manipulation check correct |
| --- | --- | --- | --- |
| core_N0 | 473 | 0.719 [0.679, 0.759] | 2.9% |
| core_N1 | 470 | 0.664 [0.621, 0.706] | 36.7% |
| core_N4 | 471 | 0.658 [0.612, 0.703] | 27.3% |
| core_N19 | 473 | 0.674 [0.632, 0.715] | 10.8% |
| core_N99 | 472 | 0.684 [0.644, 0.729] | 12.9% |
| core_N999 | 474 | 0.694 [0.652, 0.734] | 13.5% |
| designated_N0 | 476 | 0.708 [0.666, 0.750] | 2.3% |
| designated_N99 | 475 | 0.680 [0.636, 0.722] | 15.0% |
| notool_N0 | 467 | 0.000 [0.000, 0.000] | 8.8% |
| notool_N99 | 464 | 0.000 [0.000, 0.000] | 12.5% |
| silence_N1 | 478 | 0.833 [0.799, 0.864] | 38.5% |
| silence_N4 | 479 | 0.843 [0.810, 0.873] | 24.4% |
| silence_N19 | 477 | 0.845 [0.809, 0.876] | 5.4% |
| silence_N99 | 478 | 0.814 [0.778, 0.849] | 5.6% |
| silence_N999 | 478 | 0.824 [0.789, 0.860] | 5.2% |
| twin_N0 | 466 | 0.373 [0.333, 0.418] | 2.9% |
| twin_N99 | 472 | 0.345 [0.303, 0.390] | 20.6% |

- H1 GEE slope on log10(N+1): +0.002 [-0.061, +0.065] (supported: False)
- H1 fixed-effects linear slope: +0.000 [-0.015, +0.015]
- H1 slope, manipulation check passed only: -0.442 [-0.634, -0.251]
- N=0 minus N=99: +0.039 [-0.013, +0.086]; within +-5 points: False
- H2 interaction (x silence): -0.110 [-0.239, +0.021]
- H3 designated N=99 minus core N=0: -0.038 [-0.088, +0.015] (supported: False)
- H4 board posts without report tool, N=99 minus N=0: -0.044 [-0.094, +0.009]
- Measure check, violation minus harmless twin at N=0: +0.346 [+0.290, +0.401]
- Measure check, designated minus not designated at N=99: +0.004 [-0.049, +0.058]
- The report rate moves in at least one measure check: True

## tiiuae/Falcon3-7B-Instruct

8160 decisions, 480 scenarios, parse rate 97.4%.

| Cell | Parsed decisions | Report rate [95% CI] | Manipulation check correct |
| --- | --- | --- | --- |
| core_N0 | 462 | 0.688 [0.645, 0.732] | 24.2% |
| core_N1 | 464 | 0.692 [0.649, 0.733] | 22.7% |
| core_N4 | 464 | 0.679 [0.638, 0.720] | 76.7% |
| core_N19 | 466 | 0.663 [0.620, 0.704] | 69.4% |
| core_N99 | 469 | 0.663 [0.618, 0.708] | 67.1% |
| core_N999 | 463 | 0.678 [0.635, 0.717] | 71.5% |
| designated_N0 | 465 | 0.684 [0.641, 0.725] | 30.8% |
| designated_N99 | 472 | 0.672 [0.627, 0.714] | 75.2% |
| notool_N0 | 467 | 0.000 [0.000, 0.000] | 18.1% |
| notool_N99 | 469 | 0.000 [0.000, 0.000] | 58.8% |
| silence_N1 | 478 | 0.866 [0.837, 0.895] | 19.6% |
| silence_N4 | 476 | 0.878 [0.851, 0.908] | 85.8% |
| silence_N19 | 476 | 0.916 [0.891, 0.939] | 64.4% |
| silence_N99 | 479 | 0.925 [0.902, 0.948] | 60.2% |
| silence_N999 | 474 | 0.899 [0.871, 0.924] | 62.7% |
| twin_N0 | 443 | 0.343 [0.300, 0.391] | 35.2% |
| twin_N99 | 457 | 0.326 [0.289, 0.372] | 68.3% |

- H1 GEE slope on log10(N+1): -0.032 [-0.096, +0.033] (supported: False)
- H1 fixed-effects linear slope: -0.007 [-0.023, +0.008]
- H1 slope, manipulation check passed only: +0.068 [-0.031, +0.167]
- N=0 minus N=99: +0.024 [-0.020, +0.075]; within +-5 points: False
- H2 interaction (x silence): +0.179 [+0.022, +0.336]
- H3 designated N=99 minus core N=0: -0.011 [-0.061, +0.037] (supported: False)
- H4 board posts without report tool, N=99 minus N=0: -0.018 [-0.070, +0.035]
- Measure check, violation minus harmless twin at N=0: +0.356 [+0.295, +0.417]
- Measure check, designated minus not designated at N=99: +0.011 [-0.041, +0.063]
- The report rate moves in at least one measure check: True

H1 supported in 0 of 4 models (preregistered bar: at least 2 models).
