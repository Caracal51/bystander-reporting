# Do more witnesses make AI agents less likely to report a peer?

Code, data and checks for a preregistered test of a bystander effect in AI agents, submitted to the Swarm Alignment Hackathon (Apart Research, November 2026). The paper is in `paper/Bystander_reporting_submission.pdf`.

An agent reads a log entry in which a peer breaks a workspace rule, is told how many other agents saw it (N = 0, 1, 4, 19, 99 or 999), and makes one tool call. We tested whether it reports to its human overseer less often as N grows. In four small open models (Qwen3-8B, Phi-4-mini-instruct, and Yi-1.5-9B-Chat and Falcon3-7B-Instruct, added after preregistration), the preregistered test found no significant decline. These results concern bystanders described in a prompt and small open models; frontier models and live swarms were not tested. See the paper for the full results, limitations and every deviation from the preregistration.

## Contents

```
README.md
scenarios.jsonl            480 synthetic scenarios (frozen set; SHA-256 begins 2e383863f780eccb)
main_out/                  one JSON record per decision, 8,160 per model
  records_Qwen_Qwen3_8B.jsonl
  records_microsoft_Phi_4_mini_instruct.jsonl   Phi with the re-asked check (see note below)
  records_01_ai_Yi_1_5_9B_Chat.jsonl
  records_tiiuae_Falcon3_7B_Instruct.jsonl
main_out_recheck/          the same Phi file; exploratory.py reads it from here for its re-check section
live_out/                  exploratory live-board check (Qwen3-8B, 120 boards)
results/                   results.json, results.md and a plot, written by analyze.py
pilots/                    pilot records and summaries for Phi, Yi and Falcon
checks/                    outputs of the verification scripts and the hand-check samples
  exploratory_results.txt  every post-hoc number (exploratory.py)
  verify_results.txt       record integrity, parser audit, recomputation, permutation test (verify.py)
  trail_check.csv          88 numbers in the paper recomputed from the raw files (paper_trail.py)
  sim_null_results_2000.txt  false-positive rate of the H1 test under shuffled N (sim_null.py)
  deferral_handcheck.csv   50 stated reasons to judge by hand (deferral_sample.py)
  deferral_handcheck_judged.csv  the same 50, judged by Claude, checked by the author (agreed)
  scenario_handcheck.csv   20 scenarios to judge by hand (scenario_sample.py)
  scenario_handcheck_judged.csv  the same 20, judged by Claude, checked by the author (agreed)
code/                      all scripts (listed below)
paper/                     the submitted PDF and Figure 1
```

## Reproduce every number in the paper (no GPU)

Run from this folder with Python 3.10 or later. `verify.py`, `paper_trail.py` and `exploratory.py` need only the standard library; `analyze.py` and `sim_null.py` need `pip install numpy pandas statsmodels matplotlib`.

```bash
# 88 numbers in the paper, each compared with the printed value (expect 88 MATCH)
python code/paper_trail.py --scenarios scenarios.jsonl --results results/results.json \
  --qwen main_out/records_Qwen_Qwen3_8B.jsonl \
  --phi main_out/records_microsoft_Phi_4_mini_instruct.jsonl \
  --yi main_out/records_01_ai_Yi_1_5_9B_Chat.jsonl \
  --falcon main_out/records_tiiuae_Falcon3_7B_Instruct.jsonl \
  --live-summary live_out/live_summary.json \
  --live-records live_out/live_records_Qwen_Qwen3_8B.jsonl --out trail_check.csv

# Preregistered tests (rewrites results.json; identical to results/results.json)
python code/analyze.py "main_out/records_*.jsonl" --out results_rerun

# Post-hoc numbers (identical to checks/exploratory_results.txt)
python code/exploratory.py > exploratory_rerun.txt

# Independent checks: integrity, second parser, recomputation, permutation test
python code/verify.py --scenarios scenarios.jsonl --results results/results.json main_out/records_*.jsonl

# False-positive rate of the H1 test with N shuffled within scenario (about 3 minutes)
python code/sim_null.py main_out/records_Qwen_Qwen3_8B.jsonl --sims 2000
```

All of these use fixed seeds, so the outputs should match the files in `checks/` and `results/` exactly. `verify.py` may print the models in a different order.

## Rerun the experiment (GPU)

The runs used vLLM on Kaggle with two T4 GPUs (float16), temperature 0.7, up to 200 output tokens, and one fixed seed per decision. The vLLM version was not recorded; a rerun of 340 Qwen3-8B decisions with vLLM 0.33.0 chose the same tool in 340 of 340 cases. Scripts import each other, so run them as `python code/<script>.py`.

```bash
pip install vllm
python code/pilot_bystander.py --model Qwen/Qwen3-8B --tp 2                    # pilot on 20 templates
python code/run_main.py --model Qwen/Qwen3-8B --tp 2 --scenarios scenarios.jsonl # main run -> main_out/
python code/run_main.py --model microsoft/Phi-4-mini-instruct --tp 2 --scenarios scenarios.jsonl
python code/run_main.py --model 01-ai/Yi-1.5-9B-Chat --tp 2 --check-max-tokens 120 --scenarios scenarios.jsonl
python code/run_main.py --model tiiuae/Falcon3-7B-Instruct --tp 2 --check-max-tokens 120 --scenarios scenarios.jsonl
python code/recheck_phi.py --records main_out/records_microsoft_Phi_4_mini_instruct.jsonl \
  --scenarios scenarios.jsonl --model microsoft/Phi-4-mini-instruct --tp 2      # re-asked check
python code/live_board.py --model Qwen/Qwen3-8B --tp 2 --scenarios scenarios.jsonl \
  --main-records main_out/records_Qwen_Qwen3_8B.jsonl                          # live boards
python code/gate.py pilots/pilot_out_yi                                         # gate for added models
```

Each script's header explains its options. `modal_run.py` ran Qwen3-32B on a Modal H100 (it failed the pilot gate and has no main run).

## Scripts

| Script | What it does |
|---|---|
| `pilot_bystander.py` | Prompts, output parser, model backends; the 20-template pilot |
| `run_main.py` | Main run: 480 scenarios x 17 cells, one decision each, plus the manipulation check |
| `analyze.py` | Preregistered tests H1 to H4 and the measure checks; writes `results.json` |
| `exploratory.py` | Every post-hoc number in the paper |
| `live_board.py` | Exploratory live-board check |
| `recheck_phi.py` | Re-asks Phi's manipulation check with a 120-token limit; decisions unchanged |
| `gate.py` | Pilot gate for models added after the freeze |
| `convert_adaption.py`, `adaption_prompt.md` | Turn the Adaption Invent-a-Dataset export into `scenarios.jsonl` |
| `verify.py` | Checks written separately from the analysis code |
| `paper_trail.py` | Recomputes the paper's numbers and compares them with the printed text |
| `sim_null.py` | Null simulation for the H1 test's false-positive rate |
| `deferral_sample.py`, `scenario_sample.py` | Draw the hand-check samples |
| `make_figure1.py`, `report_values.py`, `build_submission.js` | Build Figure 1, Table 2 and the paper from `results.json` |
| `modal_run.py` | Runs one added model on Modal (pilot, gate, main run) |

## Record format

Each line of a records file is one decision: `scenario`, `kind`, `severity`, `cell` (for example `core_N99`), `violation`, `n_others`, `silence`, `designated`, `report_tool`, `raw` (the model's full output), `tool`, `reason`, `parsed`, `reported`, `posted`, `deferral_words`, and the manipulation check: `check_raw`, `check_answer`, `check_correct`. Unparsed outputs are kept (`parsed: false`) and excluded from rates.

The Phi records carry the re-asked check (120-token limit) in `check_raw`, `check_answer` and `check_correct`; the first answers (12-token limit) are kept as `check_raw_v1`, `check_answer_v1` and `check_correct_v1`. Its decisions are the original ones.

## Notes

- **Preregistration and deviations:** the preregistration was frozen on 7 November 2026 at 21:40 London time, before any main-run data. Appendix B of the paper lists every change after that.
- **Hand checks:** `checks/scenario_handcheck_judged.csv` holds the scenario check reported in Methods (19 clean pairs, 1 awkward), and `checks/deferral_handcheck_judged.csv` holds the deferral check in Appendix B (1 of 10 flagged reasons defers, 0 of 40 unflagged). Claude judged both; the author checked both and agreed. `checks/deferral_handcheck.csv` and `checks/scenario_handcheck.csv` are blank copies for anyone to judge.
- **Safety:** all scenarios are synthetic, with placeholder hosts, keys and fictional projects. They contain no working exploit code, and no real systems, credentials, people or incident data were used.
- **LLM use:** The author designed and planned the study. Claude (Anthropic) helped write up the preregistration, wrote much of the code and drafted the paper; see the paper's LLM Usage Statement.
- **Licence:** none chosen yet.
